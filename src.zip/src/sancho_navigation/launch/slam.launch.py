from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node # <--- Necesitamos esto
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    
    # 1. El algoritmo de SLAM (Matemáticas)
    slam_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('slam_toolbox'),
                'launch',
                'online_async_launch.py'
            )
        ),
        launch_arguments={'use_sim_time': 'true'}.items()
    )

    # 2. El visualizador RViz (Gráficos) -> ¡ESTO ES LO NUEVO!
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        # Si quieres que se abra con tu configuración guardada, descomenta esto cuando tengas un .rviz:
        # arguments=['-d', '/ruta/a/tu/configuracion.rviz']
    )

    return LaunchDescription([
        slam_launch,
        rviz_node # <--- Añadimos el nodo a la lista
    ])